<?php
require FCPATH.'modules/form/config/forms.php';
// $config['schema_vars'] = $configItems;
$config = $config['forms'];
$config['page'] = 'Static Page';
$config['form'] = 'Form';
$config['content'] = 'Page Content';
$config['image_gallery'] = 'Image Gallery';