<form action="center/update">
    <input type="hidden" name="id" value="{id}">
    <div class="row">
        
    </div>
</form>