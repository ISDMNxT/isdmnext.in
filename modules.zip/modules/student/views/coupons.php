<div class="row">
    <div class="col-md-12">
        <div class="{card_class}">
            <div class="card-header">
                <h3 class="card-title">List All Coupons</h3>
            </div>
            <div class="card-body">
                <table class="table table-striped table-hover table-bordered" id="coupons">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Referred BY</th>
                            <th>Student</th>
                            <th>Coupon</th>
                            <th>Status</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>

                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>