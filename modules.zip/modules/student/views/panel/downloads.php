<div class="col-md-12 mt-5">
    <div class="{card_class}">
        <div class="card-header">
            <h3 class="card-title">List Downloads</h3>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-hover table-striped" id="list-downloads">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Title</th>
                            <th>Description</th>
                            <th>Download Type</th>
                            <th>Files</th>
                        </tr>
                    </thead>
                    <tbody>
                        
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>