<input type="hidden" name="id" id="id" value="{id}">
<div class="form-group mb-4">
    <label class="form-label required">Amount</label>
    <input type="text" name="amount" id="amount" class="form-control" placeholder="Enter Amount" value="{amount}">
</div>
<div class="form-group mb-4">
    <label class="form-label required">Description</label>
    <input type="text" name="description" id="description" class="form-control" placeholder="Description" value="{description}">
</div>