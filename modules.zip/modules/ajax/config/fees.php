<?php
$config['searching_types'] = [
        'admission_fees' => 'Admission Fees',
        're_admission_fees' => 'Re-Admission Fees',
        'course_fees' => 'Course Fees',
        'exam_fees' => 'Exam Fees',
        're_exam_fees' => 'Re-Exam Fees'
];