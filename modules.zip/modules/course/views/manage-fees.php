<div class="row">
    <div class="col-md-4">
        <div class="{card_class}">
            <div class="card-header collapsible cursor-pointer rotate" data-bs-toggle="collapse"
                data-bs-target="#kt_docs_card_collapsible1">
                <h3 class="card-title">Select Course</h3>
                <div class="card-toolbar rotate-180">
                    <i class="ki-duotone ki-down fs-1"></i>
                </div>
            </div>
            <div id="kt_docs_card_collapsible1" class="collapse show">
                <div class="card-body print-all-course">

                </div>
            </div>
        </div>
    </div>
    <div class="col-md-8 ">
        <!-- manage-fees-box -->
        <div class="{card_class}">
            <div class="card-header collapsible cursor-pointer rotate" data-bs-toggle="collapse"
                data-bs-target="#kt_docs_card_collapsible">
                <h3 class="card-title">Manage Fees of  &nbsp;<b class="course_name text-info fs-2"></b> &nbsp;Course</h3>
                <div class="card-toolbar rotate-180">
                    <i class="ki-duotone ki-down fs-1"></i>
                </div>
            </div>
            <div id="kt_docs_card_collapsible" class="collapse show">
                <div class="card-body my-body">
                    <div class="alert bg-info text-white">Please Select A Course</div>
                </div>
            </div>
        </div>
    </div>
</div>