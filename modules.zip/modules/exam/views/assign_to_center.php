<div class="row">
    <div class="col-md-12">
        <form action="" id="assign-to-center">
            <div class="{card_class}">
                <div class="card-header">
                    <h3 class="card-title">Assign To Centre</h3>
                </div>
                <div class="card-body">
                    
                </div>
                <div class="card-footer">
                    {save_button}
                </div>
            </div>
        </form> 
    </div>
</div>