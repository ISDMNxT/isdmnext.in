<?php
$config['forms'] = [
    'student_admission' => 'Student Admission Form',
    'student_login' => 'Student Login Form',
    'student_verification' => 'Student Verification Form',
    'result_verification' => 'Result Verification Form',
    'admit_card' => 'Admit Card Form',
    'cerificate_verification' => 'Certificate verification Form',
    'search_center' => 'Search Study Center',
    'apply_franchise' => 'Franchise Apply Form',
    'franchise_verification' => 'Franchise Verification Form'
];