<?php
class Login extends MY_Controller
{
    function index()
    {
        $this->parse('admin_login');
    }
}
?>
